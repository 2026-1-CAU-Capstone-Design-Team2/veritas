from __future__ import annotations

import argparse
from pathlib import Path

from agent import ChatAgent
from core.stdio_utf8 import force_utf8_stdio
from llm.llama_server_llm import LLMClient
from services.rag_service import RAGService
from tools.loader import build_registry, load_schema
from tools.autosurvey_tool import AutoSurveyTool
from workflows import AutoSurveyWorkflow


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Veritas AutoSurvey + RAG runner")
    parser.add_argument("instruction", nargs="?", help="Natural language instruction or question")
    parser.add_argument("--output-dir", required=True, help="Root directory for outputs")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--embed-host", default=None)
    parser.add_argument("--embed-port", type=int, default=8081)
    parser.add_argument(
        "--parallel",
        type=int,
        default=None,
        help=(
            "Max concurrent LLM requests for batch work (per-document cleanup, "
            "summaries, embeddings). Should match llama-server's -np slot count. "
            "Default: VERITAS_LLM_PARALLEL env, or 1 (serial)."
        ),
    )
    parser.add_argument("--batch-size", type=int, default=5)
    parser.add_argument("--scout-docs", type=int, default=3)
    parser.add_argument("--max-docs", type=int, default=15)
    parser.add_argument("--max-context", type=int, default=16384)
    parser.add_argument("--rag-results", type=int, default=5)
    parser.add_argument(
        "--phase",
        choices=["all", "plan", "collect", "summarize", "final", "rag", "chat"],
        default="all",
        help=(
            "Which phase to run. rag = force document-grounded RAG chat; "
            "chat = normal chat with schema-driven tool use."
        ),
    )
    parser.add_argument("--force-plan", action="store_true")
    parser.add_argument("--overwrite-summaries", action="store_true")
    parser.add_argument("--stream-summary", action="store_true")
    parser.add_argument("--stream-reasoning", action="store_true")
    parser.add_argument("--no-trace-latency", action="store_true")
    parser.add_argument("--markdown-root", default=None, help="Root directory for markdown indexing")
    parser.add_argument("--no-rag", action="store_true", help="Skip RAG chat after survey completes")
    parser.add_argument("--reindex", action="store_true", help="Force re-indexing of documents into vector store")
    parser.add_argument(
        "--no-screen-context",
        action="store_true",
        help="Disable screen-context polling and proactive chat interventions.",
    )
    parser.add_argument(
        "--screen-interval",
        type=float,
        default=5.0,
        help="Seconds between foreground-window context captures in chat mode.",
    )
    parser.add_argument(
        "--screen-debug",
        "--screen-debug-log",
        dest="screen_debug_log",
        action="store_true",
        help="Print screen-context capture diagnostics to the console. JSONL capture logs are always saved.",
    )
    return parser.parse_args()


def ensure_rag_index(
    args: argparse.Namespace,
    rag_service: RAGService,
    output_dir: Path,
    run_store_service,
    *,
    require_documents: bool = True,
) -> bool:
    existing_chunks = rag_service.get_document_count()

    if args.reindex or existing_chunks == 0:
        markdown_root = (
            Path(args.markdown_root).expanduser().resolve()
            if args.markdown_root
            else output_dir
        )

        clean_md_dir = run_store_service.clean_md_dir
        has_clean_md = clean_md_dir.exists() and any(clean_md_dir.glob("*.md"))

        if has_clean_md and markdown_root == output_dir:
            print("[info] Indexing AutoSurvey clean_md documents for RAG...")
            indexed = rag_service.index_autosurvey_output(
                clean_md_dir=clean_md_dir,
                index_path=run_store_service.index_path,
                clear_first=True,
            )
        else:
            print(f"[info] Indexing markdown files under {markdown_root}...")
            indexed = rag_service.index_all_markdown(
                base_dir=markdown_root,
                clear_first=True,
            )

        if indexed == 0:
            message = "No documents were indexed. Check --output-dir/--markdown-root and generated summaries."
            if require_documents:
                print(f"[error] {message}")
                return False
            print(f"[warn] {message} Continuing chat without RAG documents.")
    else:
        print(f"[info] Using existing index ({existing_chunks} chunks)")

    # CLI option should control service retrieval count even when service was built
    # with defaults in tools.loader.
    rag_service.n_results = args.rag_results
    return True


def run_chat(
    args: argparse.Namespace,
    *,
    llm: LLMClient,
    registry,
    rag_service: RAGService,
    output_dir: Path,
    run_store_service,
    mode: str,
) -> None:
    if not ensure_rag_index(
        args,
        rag_service,
        output_dir,
        run_store_service,
        require_documents=(mode == "rag"),
    ):
        return

    chat_agent = ChatAgent(
        llm=llm,
        rag_service=rag_service,
        tool_registry=registry,
        screen_debug=args.screen_debug_log,
    )
    chat_agent.chat_loop(
        mode=mode,
        enable_screen_context=(mode == "auto" and not args.no_screen_context),
    )




def register_chat_workflow_tools(*, registry, workflow, rag_service, run_store_service) -> None:
    """Register high-level workflow adapters that may be exposed to chat agents.

    Internal AutoSurvey tools remain registered for the workflow itself, but chat
    only sees the autosurvey adapter through ChatAgent's allowlist.
    """
    if registry.has("autosurvey"):
        return

    schema_path = Path(__file__).resolve().parent / "tools" / "autosurvey_tool" / "tool_schema.json"
    registry.register(
        AutoSurveyTool(
            schema=load_schema(schema_path),
            workflow=workflow,
            rag_service=rag_service,
            run_store_service=run_store_service,
            max_docs_cap=5,
        )
    )


def main() -> None:
    # AutoSurvey document cleanup logs web-scraped text (em-dashes, smart
    # quotes); on Korean Windows a piped stdout defaults to cp949 and such a
    # print raises UnicodeEncodeError. Force UTF-8 before any output.
    force_utf8_stdio()
    args = parse_args()

    output_dir = Path(args.output_dir).expanduser().resolve()
    llm = LLMClient(
        host=args.host,
        port=args.port,
        embed_host=args.embed_host,
        embed_port=args.embed_port,
        stream_summary=args.stream_summary,
        stream_reasoning=args.stream_reasoning,
        trace_latency=not args.no_trace_latency,
        max_parallel=args.parallel,
    )

    registry, run_store_service, rag_service = build_registry(
        llm=llm,
        run_root=output_dir,
        batch_size=args.batch_size,
        max_context=args.max_context,
        enable_screen_context=not args.no_screen_context,
        screen_interval_sec=args.screen_interval,
        screen_debug_log=args.screen_debug_log,
    )

    workflow = AutoSurveyWorkflow(
        registry=registry,
        run_store_service=run_store_service,
        max_docs=args.max_docs,
        collect_batch_size=args.batch_size,
        scout_docs=args.scout_docs,
    )
    register_chat_workflow_tools(
        registry=registry,
        workflow=workflow,
        rag_service=rag_service,
        run_store_service=run_store_service,
    )

    print(f"[info] output directory = {output_dir}")

    if args.phase == "plan":
        if not args.instruction:
            raise SystemExit("instruction is required for --phase plan")
        plan = workflow.run_plan(args.instruction, force_plan=args.force_plan)
        print(f"[done] plan saved: {run_store_service.plan_path}")
        print(plan)
        return

    if args.phase == "collect":
        user_request = args.instruction or run_store_service.load_request()
        plan = workflow.run_plan(user_request, force_plan=args.force_plan)
        result = workflow.run_collect(plan)
        print(f"[done] collected {result['record_count']} record(s)")
        return

    if args.phase == "summarize":
        result = workflow.run_summarize(overwrite=args.overwrite_summaries)
        print("[done] summaries updated")
        print(result)
        return

    if args.phase == "final":
        user_request = args.instruction or run_store_service.load_request()
        result = workflow.run_final(user_request=user_request)
        print(f"[done] final report saved: {result['final_path']}")
        return

    if args.phase == "rag":
        run_chat(
            args,
            llm=llm,
            registry=registry,
            rag_service=rag_service,
            output_dir=output_dir,
            run_store_service=run_store_service,
            mode="rag",
        )
        return

    if args.phase == "chat":
        run_chat(
            args,
            llm=llm,
            registry=registry,
            rag_service=rag_service,
            output_dir=output_dir,
            run_store_service=run_store_service,
            mode="auto",
        )
        return

    # Auto-detect mode: no instruction + existing markdown data -> schema-driven chat.
    has_any_markdown = any(output_dir.rglob("*.md"))
    if not args.instruction and args.phase == "all":
        if has_any_markdown:
            print("[info] No instruction provided, but documents exist. Entering schema-driven chat mode.")
            run_chat(
                args,
                llm=llm,
                registry=registry,
                rag_service=rag_service,
                output_dir=output_dir,
                run_store_service=run_store_service,
                mode="auto",
            )
            return
        raise SystemExit("instruction is required (or use --phase rag/--phase chat with existing data)")

    # Full survey pipeline
    result = workflow.run_all(
        user_request=args.instruction,
        force_plan=args.force_plan,
        overwrite_summaries=args.overwrite_summaries,
    )
    print(f"[done] final report saved: {run_store_service.final_path}")
    print(result["final_result"])

    # Enter schema-driven chat after survey unless explicitly skipped.
    if not args.no_rag:
        print("\n" + "=" * 60)
        print("Survey complete! Entering schema-driven chat mode...")
        print("=" * 60)
        run_chat(
            args,
            llm=llm,
            registry=registry,
            rag_service=rag_service,
            output_dir=output_dir,
            run_store_service=run_store_service,
            mode="auto",
        )


if __name__ == "__main__":
    main()
